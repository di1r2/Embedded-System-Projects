#include <reg51.h>

sbit red1 = P2^0;
sbit yellow1 = P2^1;
sbit green1 = P2^2;

sbit red2 = P2^3;
sbit yellow2 = P2^4;
sbit green2 = P2^5;

sbit red3 = P3^0;
sbit yellow3 = P3^1;
sbit green3 = P3^2;

void delay(unsigned int t);
void trafficlight(void);
void main(){
	
		P2 = 0x00;    //turned off the lights
		P3 = 0x00;
	
	while(1){
			trafficlight();
	}

}

void delay(unsigned int t){     //delay
		
			while(t>0){
						unsigned long int i;
						for(i=0; i<1275; i++);
						t--;
			}

}

void trafficlight(void){   //green = g, yellow = y, red = r

		P2 = 0x11;  		//g1=1, y1=0, r1=0
		P3 = 0x04;			//g2=0, y2=1, r2=0
										//g3=0, y3=0, r3=1
		delay(100);
		P2 = 0x0c;  		//g1=0, y1=0, r1=1
		P3 = 0x02;			//g2=1, y2=0, r2=0
									 //g3=0, y3=1, r3=0
		delay(100);
		P2 = 0x22;  		//g1=0, y1=1, r1=0
		P3 = 0x01;			//g2=0, y2=0, r2=1
									 //g3=1, y3=0, r3=0
		delay(100);
}