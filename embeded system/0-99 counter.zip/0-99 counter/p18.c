#include<reg51.h>
void delay();
void main()
{
unsigned char seg[10]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90}; 
unsigned char ch1,ch2;// for loop repetion one by one 
P2=0x00;
P3=0x00;//output configuration
while(1)
{
	for(ch1=0;ch1<10;ch1++)
	{
   P2=seg[ch1];
	for(ch2=0;ch2<10;ch2++)
	{
   P3=seg[ch2];
		delay();
	}
		
	}
}
}
void delay(){
unsigned int i;
for(i=0;i<30000;i++);
}